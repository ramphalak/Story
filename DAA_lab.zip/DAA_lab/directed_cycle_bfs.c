#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adj[MAX][MAX];
int indegree[MAX];

int bfsCycleDetection(int n) {
    int queue[MAX], front = 0, rear = 0;
    int count = 0;

    // Enqueue all vertices with indegree 0
    for (int i = 0; i < n; i++)
        if (indegree[i] == 0)
            queue[rear++] = i;

    while (front < rear) {
        int v = queue[front++];
        count++;

        for (int u = 0; u < n; u++) {
            if (adj[v][u]) {
                indegree[u]--;
                if (indegree[u] == 0)
                    queue[rear++] = u;
            }
        }
    }

    return count != n; // If not all vertices were processed, there's a cycle
}

int main() {
    int n, e;
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter %d directed edges (u -> v):\n", e);
    for (int i = 0; i < e; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        adj[u][v] = 1;
        indegree[v]++;
    }

    printf("\nAdjacency Matrix:\n   ");
    for (int i = 0; i < n; i++) printf("%d ", i);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%d: ", i);
        for (int j = 0; j < n; j++)
            printf("%d ", adj[i][j]);
        printf("\n");
    }

    if (bfsCycleDetection(n))
        printf("Cycle detected (BFS - Kahn’s Algorithm).\n");
    else
        printf("No cycle found (BFS - Kahn’s Algorithm).\n");

    return 0;
}
