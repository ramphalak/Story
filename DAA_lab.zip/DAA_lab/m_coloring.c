#include <stdio.h>
#include <stdbool.h>

#define V 10  // Max number of vertices (can change as needed)

int graph[V][V];   // Adjacency matrix
int color[V];      // Color assignment for vertices
int n;             // Actual number of vertices
int m;             // Number of colors

// Function to check if it's safe to color vertex v with color c
bool isSafe(int v, int c) {
    for (int i = 0; i < n; i++) {
        if (graph[v][i] && color[i] == c)
            return false;
    }
    return true;
}

// Recursive utility function to solve the problem
bool graphColoring(int v) {
    if (v == n)
        return true; // All vertices are colored

    for (int c = 1; c <= m; c++) {
        if (isSafe(v, c)) {
            color[v] = c;

            if (graphColoring(v + 1))
                return true;

            color[v] = 0; // Backtrack
        }
    }

    return false;
}

void printSolution() {
    printf("Coloring of vertices:\n");
    for (int i = 0; i < n; i++)
        printf("Vertex %d --> Color %d\n", i, color[i]);
}

int main() {
    int edges;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &edges);

    // Initialize graph to 0
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            graph[i][j] = 0;

    printf("Enter %d edges (u v):\n", edges);
    for (int i = 0; i < edges; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        graph[u][v] = 1;
        graph[v][u] = 1; // Undirected graph
    }

    printf("Enter the number of colors (m): ");
    scanf("%d", &m);

    for (int i = 0; i < n; i++)
        color[i] = 0;

    if (graphColoring(0))
        printSolution();
    else
        printf("No solution exists with %d colors.\n", m);

    return 0;
}
