#include <stdio.h>
#include <limits.h>

#define MAX_VERTICES 100
#define INF INT_MAX

// Function to implement Floyd-Warshall Algorithm
void floydWarshall(int dist[MAX_VERTICES][MAX_VERTICES], int V) {
    for (int k = 0; k < V; k++) {
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (dist[i][k] != INF && dist[k][j] != INF &&
                    dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }

    // Print shortest path matrix
    printf("Shortest distances between every pair of vertices:\n");
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            if (dist[i][j] == INF)
                printf("INF ");
            else
                printf("%3d ", dist[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int V;
    int dist[MAX_VERTICES][MAX_VERTICES];

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter adjacency matrix (-1 for no edge):\n");
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            int val;
            scanf("%d", &val);

            if (i == j)
                dist[i][j] = 0;
            else if (val == -1)
                dist[i][j] = INF;
            else
                dist[i][j] = val;
        }
    }

    floydWarshall(dist, V);

    return 0;
}


// Input Format: 
// matrix[][] = { {0, 2, -1, -1},
//         {1, 0, 3, -1},{-1, -1, 0, -1},{3, 5, 4, 0} }

// Result:
// 0 2 5 -1 
// 1 0 3 -1 
// -1 -1 0 -1 
// 3 5 4 0 