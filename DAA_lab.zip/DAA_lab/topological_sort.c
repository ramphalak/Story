#include <stdio.h>
#include <stdlib.h>

// Define the maximum number of vertices
#define MAX_VERTICES 100

// Graph structure
int graph[MAX_VERTICES][MAX_VERTICES];  // Adjacency matrix
int visited[MAX_VERTICES];  // Visited array
int n;  // Number of vertices

// Function to perform DFS and store the topological order
void dfs(int v, int stack[], int *top) {
    visited[v] = 1;

    for (int i = 0; i < n; i++) {
        if (graph[v][i] == 1 && !visited[i]) {
            dfs(i, stack, top);
        }
    }

    // Push vertex onto stack after exploring all its neighbors
    stack[(*top)++] = v;
}

// Function to perform topological sort
void topologicalSort() {
    int stack[MAX_VERTICES];
    int top = 0;

    // Initialize visited array
    for (int i = 0; i < n; i++) {
        visited[i] = 0;
    }

    // Perform DFS for each unvisited vertex
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs(i, stack, &top);
        }
    }

    // Print the topological sort order
    printf("Topological Sort: ");
    for (int i = top - 1; i >= 0; i--) {
        printf("%d ", stack[i]);
    }
    printf("\n");
}

int main() {
    printf("Enter the number of vertices: ");
    scanf("%d", &n);

    // Initialize the adjacency matrix
    printf("Enter the adjacency matrix (use 0 for no edge and 1 for an edge):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Perform topological sort
    topologicalSort();

    return 0;
}
