#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];

typedef struct {
    int node;
    int parent;
} QueueNode;

int bfs(int start, int n) {
    QueueNode queue[MAX];
    int front = 0, rear = 0;

    queue[rear++] = (QueueNode){start, -1};
    visited[start] = 1;

    while (front < rear) {
        QueueNode curr = queue[front++];
        int v = curr.node;

        for (int u = 0; u < n; u++) {
            if (adj[v][u]) {
                if (!visited[u]) {
                    visited[u] = 1;
                    queue[rear++] = (QueueNode){u, v};
                } else if (u != curr.parent) {
                    return 1; // Cycle detected
                }
            }
        }
    }
    return 0;
}

int main() {
    int n, e;
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter %d edges (u v):\n", e);
    for (int i = 0; i < e; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        adj[u][v] = adj[v][u] = 1;  // Undirected graph
    }

    for (int i = 0; i < n; i++)
        visited[i] = 0;

    int cycleFound = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            if (bfs(i, n)) {
                cycleFound = 1;
                break;
            }
        }
    }

    if (cycleFound)
        printf("Cycle detected (BFS).\n");
    else
        printf("No cycle found (BFS).\n");

    return 0;
}
