#include <stdio.h>
#include <string.h>

#define MAX 256  // Total number of characters (ASCII)

// Bad Character Heuristic preprocessing
void badCharHeuristic(char *pattern, int size, int badChar[]) {
    for (int i = 0; i < MAX; i++)
        badChar[i] = -1;

    // Fill last occurrence of each character in pattern
    for (int i = 0; i < size; i++)
        badChar[(int)pattern[i]] = i;
}

// Boyer-Moore pattern search function
void boyerMoore(char *text, char *pattern) {
    int n = strlen(text);
    int m = strlen(pattern);
    int badChar[MAX];

    badCharHeuristic(pattern, m, badChar);

    int shift = 0;

    printf("Pattern found at indices: ");

    while (shift <= (n - m)) {
        int j = m - 1;

        // Compare from end of pattern
        while (j >= 0 && pattern[j] == text[shift + j])
            j--;

        if (j < 0) {
            // Pattern found
            printf("%d ", shift);

            // Shift the pattern
            shift += (shift + m < n) ? m - badChar[text[shift + m]] : 1;
        } else {
            // Mismatch found, shift pattern
            int badIndex = text[shift + j];
            int move = j - badChar[badIndex];
            shift += (move > 0) ? move : 1;
        }
    }

    printf("\n");
}

int main() {
    char text[100], pattern[100];

    printf("Enter the text (no spaces): ");
    scanf("%s", text);

    printf("Enter the pattern (no spaces): ");
    scanf("%s", pattern);

    boyerMoore(text, pattern);

    return 0;
}
