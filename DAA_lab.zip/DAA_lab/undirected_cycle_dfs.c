#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];

int dfs(int v, int parent, int n) {
    visited[v] = 1;

    for (int u = 0; u < n; u++) {
        if (adj[v][u]) {
            if (!visited[u]) {
                if (dfs(u, v, n))
                    return 1;
            } else if (u != parent) {
                return 1;  // Back edge found
            }
        }
    }
    return 0;
}

int main() {
    int n, e;
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter %d edges (u v):\n", e);
    for (int i = 0; i < e; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        adj[u][v] = adj[v][u] = 1;  // Undirected graph
    }

    for (int i = 0; i < n; i++)
        visited[i] = 0;

    int cycleFound = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            if (dfs(i, -1, n)) {
                cycleFound = 1;
                break;
            }
        }
    }

    if (cycleFound)
        printf("Cycle detected (DFS).\n");
    else
        printf("No cycle found (DFS).\n");

    return 0;
}
