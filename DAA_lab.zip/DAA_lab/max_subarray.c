#include <stdio.h>

int maxSubArray(int arr[], int n) {
    int maxSoFar = arr[0];
    int currMax = arr[0];

    for (int i = 1; i < n; i++) {
        if (currMax < 0)
            currMax = arr[i];
        else
            currMax += arr[i];

        if (currMax > maxSoFar)
            maxSoFar = currMax;
    }

    return maxSoFar;
}

int main() {
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    int result = maxSubArray(arr, n);
    printf("Maximum subarray sum = %d\n", result);

    return 0;
}
