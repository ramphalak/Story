#include <stdio.h>
#include <string.h>

#define MAX 100

// Function to compute LPS (Longest Prefix Suffix) array
void computeLPS(char* pattern, int m, int lps[]) {
    int len = 0;
    lps[0] = 0; // LPS[0] is always 0

    int i = 1;
    while (i < m) {
        if (pattern[i] == pattern[len]) {
            len++;
            lps[i] = len;
            i++;
        } else {
            if (len != 0) {
                len = lps[len - 1];
                // No increment of i here
            } else {
                lps[i] = 0;
                i++;
            }
        }
    }
}

// KMP Pattern Searching Algorithm
void KMPSearch(char* text, char* pattern) {
    int n = strlen(text);
    int m = strlen(pattern);

    int lps[MAX];
    computeLPS(pattern, m, lps);

    int i = 0; // index for text
    int j = 0; // index for pattern

    printf("Pattern found at indices: ");

    while (i < n) {
        if (pattern[j] == text[i]) {
            i++;
            j++;
        }

        if (j == m) {
            printf("%d ", i - j);
            j = lps[j - 1];
        } else if (i < n && pattern[j] != text[i]) {
            if (j != 0)
                j = lps[j - 1];
            else
                i++;
        }
    }

    printf("\n");
}

int main() {
    char text[MAX], pattern[MAX];

    printf("Enter the text (no spaces): ");
    scanf("%s", text);

    printf("Enter the pattern (no spaces): ");
    scanf("%s", pattern);

    KMPSearch(text, pattern);

    return 0;
}
