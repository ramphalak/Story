#include <stdio.h>
#include <limits.h>

// Function to find the minimum number of scalar multiplications
int matrixChainOrder(int p[], int n) {
    int m[n][n];  // m[i][j] will store the minimum cost of multiplying matrices Ai...Aj
    int s[n][n];  // s[i][j] stores the index where the optimal split happens

    // Initialize the diagonal (cost of multiplying one matrix is 0)
    for (int i = 1; i < n; i++) {
        m[i][i] = 0;
    }

    // Chain length varies from 2 to n
    for (int len = 2; len < n; len++) {
        for (int i = 1; i < n - len + 1; i++) {
            int j = i + len - 1;
            m[i][j] = INT_MAX;  // Set to maximum value initially

            // Try all possible places to split the chain
            for (int k = i; k < j; k++) {
                int q = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }

    // The minimum number of scalar multiplications is in m[1][n-1]
    printf("Minimum number of scalar multiplications: %d\n", m[1][n-1]);
    return m[1][n-1];
}

// Function to print the optimal parenthesization
void printOptimalParenthesization(int s[][100], int i, int j) {
    if (i == j) {
        printf("A%d", i);
    } else {
        printf("(");
        printOptimalParenthesization(s, i, s[i][j]);
        printOptimalParenthesization(s, s[i][j] + 1, j);
        printf(")");
    }
}

int main() {
    int n;
    printf("Enter the number of matrices: ");
    scanf("%d", &n);
    n++; // Adjust because matrices are represented as n-1 dimensions

    int p[n];
    printf("Enter the dimensions of matrices (in the form p1, p2, ..., pn):\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &p[i]);
    }

    int m[n][n], s[n][n];

    // Calculate minimum number of multiplications and print the parenthesization
    matrixChainOrder(p, n);
    printf("Optimal parenthesization is: ");
    printOptimalParenthesization(s, 1, n - 1);
    printf("\n");

    return 0;
}
