#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];
int recStack[MAX];  // to track the current recursion stack

int dfs(int v, int n) {
    visited[v] = 1;
    recStack[v] = 1;

    for (int u = 0; u < n; u++) {
        if (adj[v][u]) {
            if (!visited[u]) {
                if (dfs(u, n))
                    return 1;
            } else if (recStack[u]) {
                return 1; // back edge found
            }
        }
    }

    recStack[v] = 0;
    return 0;
}

void printAdjMatrix(int n) {
    printf("\nAdjacency Matrix:\n   ");
    for (int i = 0; i < n; i++) printf("%d ", i);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%d: ", i);
        for (int j = 0; j < n; j++)
            printf("%d ", adj[i][j]);
        printf("\n");
    }
}

int main() {
    int n, e;
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter %d directed edges (u -> v):\n", e);
    for (int i = 0; i < e; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        adj[u][v] = 1;  // Directed edge
    }

    printAdjMatrix(n);

    for (int i = 0; i < n; i++) visited[i] = recStack[i] = 0;

    int hasCycle = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i] && dfs(i, n)) {
            hasCycle = 1;
            break;
        }
    }

    if (hasCycle)
        printf("Cycle detected (DFS - Directed).\n");
    else
        printf("No cycle found (DFS - Directed).\n");

    return 0;
}
