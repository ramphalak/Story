#include <stdio.h>

struct Item {
    int weight;
    int value;
};

void swap(struct Item *a, struct Item *b) {
    struct Item temp = *a;
    *a = *b;
    *b = temp;
}

void sortByRatio(struct Item arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            float r1 = (float)arr[i].value / arr[i].weight;
            float r2 = (float)arr[j].value / arr[j].weight;
            if (r1 < r2)
                swap(&arr[i], &arr[j]);
        }
    }
}

float fractionalKnapsack(int W, struct Item arr[], int n) {
    sortByRatio(arr, n);
    float totalValue = 0.0;

    for (int i = 0; i < n; i++) {
        if (arr[i].weight <= W) {
            W -= arr[i].weight;
            totalValue += arr[i].value;
        } else {
            totalValue += arr[i].value * ((float)W / arr[i].weight);
            break;
        }
    }

    return totalValue;
}

int main() {
    int n, W;

    printf("Enter number of items: ");
    scanf("%d", &n);

    struct Item arr[n];

    printf("Enter weights:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i].weight);

    printf("Enter values:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i].value);

    printf("Enter knapsack capacity: ");
    scanf("%d", &W);

    float result = fractionalKnapsack(W, arr, n);
    printf("Maximum value in Fractional Knapsack = %.2f\n", result);

    return 0;
}
