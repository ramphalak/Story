#include <stdio.h>

// Utility function to get the number of digits in a number
int numDigits(int n) {
    int digits = 0;
    while (n != 0) {
        digits++;
        n /= 10;
    }
    return digits;
}

// Utility function to calculate power of 10 (10^n)
int powerOf10(int n) {
    int result = 1;
    for (int i = 0; i < n; i++) {
        result *= 10;
    }
    return result;
}

// Karatsuba multiplication
int karatsuba(int x, int y) {
    // Base case: if numbers are single digits, return the product directly
    if (x < 10 && y < 10) {
        return x * y;
    }

    // Get the number of digits in the larger number
    int n = (x > y) ? numDigits(x) : numDigits(y);
    int half = n / 2;

    // Split the numbers at the middle
    int power = powerOf10(half);
    int a = x / power;
    int b = x % power;
    int c = y / power;
    int d = y % power;

    // 3 recursive calls
    int ac = karatsuba(a, c);
    int bd = karatsuba(b, d);
    int ad_plus_bc = karatsuba(a + b, c + d) - ac - bd;

    // Combine the results using the formula
    return ac * powerOf10(2 * half) + ad_plus_bc * power + bd;
}

int main() {
    int x, y;

    printf("Enter two numbers to multiply: ");
    scanf("%d %d", &x, &y);

    int result = karatsuba(x, y);

    printf("Product using Karatsuba algorithm: %d\n", result);

    return 0;
}
