#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

#define MAX 20

int n;  // Number of cities
int dist[MAX][MAX];  // Distance matrix
bool visited[MAX];  // To keep track of visited cities
int minCost = INT_MAX;  // Store minimum path cost

// Backtracking function
void tsp(int pos, int count, int cost, int start) {
    if (count == n && dist[pos][start]) {
        // Completed one round-trip
        int totalCost = cost + dist[pos][start];
        if (totalCost < minCost)
            minCost = totalCost;
        return;
    }

    for (int city = 0; city < n; city++) {
        if (!visited[city] && dist[pos][city]) {
            visited[city] = true;
            tsp(city, count + 1, cost + dist[pos][city], start);
            visited[city] = false; // backtrack
        }
    }
}

int main() {
    printf("Enter the number of cities: ");
    scanf("%d", &n);

    printf("Enter the distance matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &dist[i][j]);

    for (int i = 0; i < n; i++) visited[i] = false;

    visited[0] = true;  // Start from city 0
    tsp(0, 1, 0, 0);

    printf("The minimum cost to visit all cities is: %d\n", minCost);
    return 0;
}
