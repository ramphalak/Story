#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Node structure for creating a binary tree
struct Node {
    char ch;
    int freq;
    struct Node *left;
    struct Node *right;
};

// Function to create a new Node
struct Node* newNode(char c, int f, struct Node* l, struct Node* r) {
    struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
    temp->ch = c;
    temp->freq = f;
    temp->left = l;
    temp->right = r;
    return temp;
}

// Function to print the generated Huffman codes
void printHuffmanCodes(struct Node* root, char* str) {
    if (!root)
        return;
    
    // If this is a leaf node, print the character and its Huffman code
    if (root->ch != '$') {
        printf("%c: %s\n", root->ch, str);
        return;
    }

    // Traverse left and right with updated binary strings
    char leftStr[strlen(str) + 2]; // +2 for the "0" and null terminator
    strcpy(leftStr, str);
    strcat(leftStr, "0");

    char rightStr[strlen(str) + 2];
    strcpy(rightStr, str);
    strcat(rightStr, "1");

    printHuffmanCodes(root->left, leftStr);
    printHuffmanCodes(root->right, rightStr);
}

// Function to find the min freq node between two queues
struct Node* minNode(struct Node** q1, int* size1, struct Node** q2, int* size2) {
    struct Node* temp;

    // If queue 1 is empty, pop from queue 2
    if (*size1 == 0) {
        temp = q2[0];
        for (int i = 1; i < *size2; i++) {
            q2[i - 1] = q2[i];
        }
        (*size2)--;
        return temp;
    }

    // If queue 2 is empty, pop from queue 1
    if (*size2 == 0) {
        temp = q1[0];
        for (int i = 1; i < *size1; i++) {
            q1[i - 1] = q1[i];
        }
        (*size1)--;
        return temp;
    }

    // Compare the front of both queues
    if (q1[0]->freq < q2[0]->freq) {
        temp = q1[0];
        for (int i = 1; i < *size1; i++) {
            q1[i - 1] = q1[i];
        }
        (*size1)--;
    } else {
        temp = q2[0];
        for (int i = 1; i < *size2; i++) {
            q2[i - 1] = q2[i];
        }
        (*size2)--;
    }

    return temp;
}

// Function to generate Huffman code
void generateHuffmanCode(struct Node** q1, int* size1, struct Node** q2, int* size2, int n) {
    while (*size1 > 0 || *size2 > 1) {
        struct Node* l = minNode(q1, size1, q2, size2);
        struct Node* r = minNode(q1, size1, q2, size2);
        
        struct Node* node = newNode('$', l->freq + r->freq, l, r);
        
        // Insert the newly created node into the second queue
        q2[*size2] = node;
        (*size2)++;
    }

    // Print the Huffman Codes
    printHuffmanCodes(q2[0], "");
}

// Main function
int main() {
    int n;

    // Get number of characters from user
    printf("Enter number of characters: ");
    scanf("%d", &n);

    char characters[n];
    int frequencies[n];
    
    // Input characters and their frequencies
    printf("Enter the characters and their frequencies:\n");
    for (int i = 0; i < n; i++) {
        printf("Character %d: ", i + 1);
        scanf(" %c", &characters[i]);  // Space before %c to ignore leading whitespaces
        printf("Frequency of %c: ", characters[i]);
        scanf("%d", &frequencies[i]);
    }

    struct Node* q1[n];
    struct Node* q2[n];
    int size1 = 0, size2 = 0;

    // Create nodes for each character and frequency, then push them into q1
    for (int i = 0; i < n; i++) {
        q1[size1] = newNode(characters[i], frequencies[i], NULL, NULL);
        size1++;
    }

    // Generate Huffman Code
    generateHuffmanCode(q1, &size1, q2, &size2, n);

    return 0;
}
