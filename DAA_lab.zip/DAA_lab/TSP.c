#include <stdio.h>
#include <limits.h>

#define MAX 16  // Maximum number of cities (for manageable computational complexity)

// Memoization table to store solutions to subproblems
int dp[MAX][(1 << MAX)];

// Distance matrix for the cities (adjacency matrix)
int dist[MAX][MAX];

// Utility function to calculate the minimum of two integers
int min(int a, int b) {
    return (a < b) ? a : b;
}

// Dynamic Programming approach to solve the TSP problem
int tsp(int pos, int mask, int n) {
    // If all cities have been visited, return the distance to the starting city
    if (mask == (1 << n) - 1) {
        return dist[pos][0];  // Return the distance to the starting city
    }

    // If this subproblem has already been solved, return the stored result
    if (dp[pos][mask] != -1) {
        return dp[pos][mask];
    }

    int ans = INT_MAX;  // Initialize answer to a large number

    // Try all cities as the next destination
    for (int city = 0; city < n; city++) {
        // Check if the city has already been visited
        if ((mask >> city) & 1) {
            continue;
        }

        // Calculate the new answer by moving to the next city and adding its distance
        int newAns = dist[pos][city] + tsp(city, mask | (1 << city), n);
        ans = min(ans, newAns);
    }

    // Store and return the result for this subproblem
    dp[pos][mask] = ans;
    return ans;
}

int main() {
    int n;

    printf("Enter the number of cities: ");
    scanf("%d", &n);

    // Initialize the distance matrix with user input
    printf("Enter the distance matrix (adjacency matrix):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &dist[i][j]);
        }
    }

    // Initialize the memoization table with -1
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < (1 << n); j++) {
            dp[i][j] = -1;
        }
    }

    // Call the TSP function starting from city 0 with only the starting city visited
    int result = tsp(0, 1, n);
    printf("The minimum cost to visit all cities is: %d\n", result);

    return 0;
}


// Enter the number of cities: 3
// Enter the distance matrix (adjacency matrix):
// 0
// 1000
// 5000
// 5000
// 0
// 1000
// 1000
// 5000
// 0
// The minimum cost to visit all cities is: 3000